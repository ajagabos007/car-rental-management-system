import * as Toastr from '../../node_modules/toastr/build/toastr.min.js';
Toastr;