<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumb_links', null, []); ?> 
        <li> 
            <span>/</span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.nav-link','data' => ['href' => ''.e(route('admin.users.index')).'','active' => request()->routeIs('admin.users.index')]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.users.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.users.index'))]); ?>
                <?php echo e(__('Users')); ?> 
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </li>
        <li> 
            <span>/</span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.nav-link','data' => ['href' => '#','active' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '#','active' => true]); ?>
                <?php echo e($user->name); ?>  
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </li>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header', null, []); ?> 
       <i class="fas fa-users"></i> <?php echo e($user->name); ?> | Users 
     <?php $__env->endSlot(); ?>
    
    <div class="container px-2 mx-auto  dark:text-gray-100">
        <h2 class="text-2xl font-semibold leading-tight">
           User -  <?php echo e($user->name); ?>

        </h2>

        <div class="bg-gray-100">
            <div class="container mx-auto my-5 p-5">
                <div class="md:flex no-wrap md:-mx-2 ">
                    <!-- Left Side -->
                    <div class="w-full md:w-3/12 md:mx-2">
                        <!-- Profile Card -->
                        <div class="bg-white p-3 border-t-4 border-green-400">
                            <?php if(Laravel\Jetstream\Jetstream::managesProfilePhotos()): ?>
                                <div class="image overflow-hidden">
                                    <img class="h-40 w-full mx-auto"
                                        src="<?php echo e($user->profile_photo_url); ?>"
                                        alt="">
                                </div>
                            <?php endif; ?>
                            <h1 class="text-gray-900 font-bold text-xl leading-8 my-1"> <?php echo e($user->name); ?></h1>
                            <ul
                                class="bg-gray-100 text-gray-600 hover:text-gray-700 hover:shadow py-2 px-3 mt-3 divide-y rounded shadow-sm">
                                <li class="flex items-center py-3">
                                    <span>Status</span>
                                    <span class="ml-auto"><span class="bg-green-500 py-1 px-2 rounded text-white text-sm">Active</span></span>
                                </li>
                                <li class="flex items-center py-3">
                                    <span>Member since</span>
                                    <span class="ml-auto"> <?php echo e($user->created_at->diffForHumans()); ?></span>
                                </li>
                            </ul>
                        </div>
                        <!-- End of profile card -->
                        <div class="my-4"></div>
                        <!-- Friends card -->
                        <div class="bg-white p-3 hover:shadow b">
                            <?php if (isset($component)) { $__componentOriginal400b65587ed473db4324d3143f27d22304048436 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AssignRoleForm::class, ['user' => $user] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('assign-role-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AssignRoleForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal400b65587ed473db4324d3143f27d22304048436)): ?>
<?php $component = $__componentOriginal400b65587ed473db4324d3143f27d22304048436; ?>
<?php unset($__componentOriginal400b65587ed473db4324d3143f27d22304048436); ?>
<?php endif; ?>
                        </div>
                    
                        <!-- End of friends card -->
                    </div>
                    <!-- Right Side -->
                    <div class="w-full md:w-9/12 mx-2 h-64">
                        <!-- Profile tab -->
                        <!-- About Section -->
                        <div class="bg-white p-3 shadow-sm rounded-sm">
                            <div class="flex items-center space-x-2 font-semibold text-gray-900 leading-8">
                                <span clas="text-green-500">
                                    <svg class="h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                </span>
                                <span class="tracking-wide">About</span>
                            </div>
                            <div class="text-gray-700">
                                <div class="grid md:grid-cols-2 text-sm">
                                    <div class="grid grid-cols-2">
                                        <div class="px-4 py-2 font-semibold">Full Name</div>
                                        <div class="px-4 py-2"><?php echo e($user->name); ?></div>
                                    </div>
                                    <div class="grid grid-cols-2">
                                        <div class="px-4 py-2 font-semibold">Contact No.</div>
                                        <div class="px-4 py-2"><?php echo e($user->phone_number); ?></div>
                                    </div>
                                    <div class="grid grid-cols-2">
                                        <div class="px-4 py-2 font-semibold">Email.</div>
                                        <div class="px-4 py-2">
                                            <a class="text-blue-800" href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a>
                                        </div>
                                    </div>
                                    <div class="grid ">
                                        <?php if (isset($component)) { $__componentOriginal9e6f55df41daa4494027857924b96b84453d1f69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CheckStaffForm::class, ['user' => $user] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('check-staff-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CheckStaffForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e6f55df41daa4494027857924b96b84453d1f69)): ?>
<?php $component = $__componentOriginal9e6f55df41daa4494027857924b96b84453d1f69; ?>
<?php unset($__componentOriginal9e6f55df41daa4494027857924b96b84453d1f69); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End of about section -->

                        <div class="my-4"></div>

                        <!-- Experience and education -->
                        <div class="bg-white p-3 shadow-sm rounded-sm">

                            <div class="grid grid-cols-1">
                                <div>
                                    <div class="flex items-center space-x-2 font-semibold text-gray-900 leading-8 mb-3">
                                        <span clas="text-green-500">
                                            <svg class="h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                            </svg>
                                        </span>
                                        <span class="tracking-wide">  <?php echo e($user->name); ?>'s Car Rents</span>
                                    </div>
                                            <?php echo e($bookings=$user->bookings()->orderBy('created_at','desc')->paginate(5)); ?>

                                    <hr class="mt-1">
                                    <div class="overflow-auto rounded shadow-md mt-2">
                                        <table class="w-full" >
                                            <thead class="table-header-group dark:bg-gray-700">
                                                <tr class="border-b-4 bg-black text-white font-extrabold">
                                                    <th class="text-left py-1 px-4 whitespace-nowrap">#</th>
                                                    <th class="text-left py-1 px-4 whitespace-nowrap ">Rent Code</th>
                                                    <th class="text-left py-1 px-4 whitespace-nowrap">Rented on</th>
                                                    <th class="text-left py-1 px-4 whitespace-nowrap">Price (NGN)</th>
                                                    <th class="text-center py-1 px-4 whitespace-nowrap">Payment</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="border-b-2 text-sm hover:bg-green-100 odd:bg-white even:text-green-900'">
                                                    <td class="py-1 px-4 whitespace-nowrap">
                                                        <?php echo e(++$loop->index); ?>

                                                    </td>
                                                    <td class="py-1 px-4 whitespace-nowrap">
                                                        <a href="<?php echo e(route('admin.bookings.show', $booking)); ?>" class="text-blue-900 hover:underline">
                                                            <?php echo e($booking->code); ?>

                                                        </a>
                                                    </td>
                                                    <td class="py-1 px-4 whitespace-nowrap">
                                                        <?php echo e($booking->created_at->diffForHumans()); ?>

                                                    </td>
                                                    <td class="py-1 px-4 whitespace-nowrap">
                                                        <a href="<?php echo e(route('admin.bookings.show', $booking)); ?>" class="text-blue-900 hover:underline">
                                                            <?php echo e($booking->amount); ?>

                                                        </a>
                                                    </td>
                                                    <td class="py-1 px-4 whitespace-nowrap">
                                                        <a href="<?php echo e(route('payments.show', $booking->payment)); ?>" class="text-blue-900 hover:underline">
                                                        <?php echo e($booking->payment->transaction_reference); ?>

                                                        </a>
                                                    </td>
                                                </tr> 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                               
                            </div>
                            <!-- End of Experience and education grid -->
                        </div>
                        <div class="my-4"></div>
                         <!-- User Direct Permission -->
                         <div class="bg-white p-3 shadow-sm rounded-sm">

                            <div class="grid grid-cols-1">
                                <div>
                                    <?php if (isset($component)) { $__componentOriginale80b39c6e899b940dd52bd44d949a7646bbfaa6c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AssignPermissionForm::class, ['user' => $user] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('assign-permission-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AssignPermissionForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale80b39c6e899b940dd52bd44d949a7646bbfaa6c)): ?>
<?php $component = $__componentOriginale80b39c6e899b940dd52bd44d949a7646bbfaa6c; ?>
<?php unset($__componentOriginale80b39c6e899b940dd52bd44d949a7646bbfaa6c); ?>
<?php endif; ?>
                                </div>
                            </div>
                            <!-- End of User Direct Permission grid -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/admin/users/show.blade.php ENDPATH**/ ?>