
  <div class="w-20 hover:w-52 group bg-green-700 min-h-screen p-5 text-white duration-300">
    <div class="relative">
        <a href="<?php echo e(route('home')); ?>" class="flex justify-center">
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.application-mark','data' => ['class' => 'block h-9 w-auto float-left']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-application-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block h-9 w-auto float-left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </a> 
        <hr class="mt-5">
        <p class="text-green-200 text-center italic text-xs"> 
          <i class="fas fa-user-tie"></i>
          <span class="hidden group-hover:inline text-sm"><?php echo e(Auth::user()->name); ?></span>
        </p>
        <hr>
        <div class="mt-4 flex justify-center">
          <ul class="w-full">
            <li class="flex">
              <a href="<?php echo e(route('admin.dashboard')); ?>" class="rounded mb-1 lg:w-full hover:bg-white hover:text-green-800 p-2 <?php echo e(request()->routeIs('admin.dashboard')?'bg-white text-green-800 ':''); ?>" >
                <i class="fas fa-tachometer-alt"> </i> <span class="hidden group-hover:inline text-sm">Dashboard</span> 
              </a>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view cars', 'create cars', 'edit cars','delete cars'])): ?>
              <li class="flex">
                <a href="<?php echo e(route('admin.cars.index')); ?>" class="rounded mb-1 lg:w-full hover:bg-white hover:text-green-800 hover:rounded p-2 <?php echo e(request()->routeIs('admin.hotels*')?'bg-white text-green-800 ':''); ?>">
                  <i class="fas fa-car"> </i> <span class="hidden group-hover:inline text-sm"> Cars</span> 
                </a>
              </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view bookings', 'create bookings', 'edit bookings','delete bookings'])): ?>
              <li class="flex">
                <a href="<?php echo e(route('admin.bookings.index')); ?>" class="rounded mb-1 lg:w-full hover:bg-white hover:text-green-800 hover:rounded p-2 <?php echo e(request()->routeIs('admin.bookings*')?'bg-white text-green-800 ':''); ?>">
                  <i class="fas fa-book-open"> </i> <span class="hidden group-hover:inline text-sm"> Rents</span> 
                </a>
              </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view roles', 'create roles', 'edit roles','delete roles'])): ?>
              <li class="flex">
                <a href="<?php echo e(route('admin.roles.index')); ?>" class="rounded mb-1 lg:w-full hover:bg-white hover:text-green-800 hover:rounded p-2 <?php echo e(request()->routeIs('admin.roles*')?'bg-white text-green-800 ':''); ?>">
                <i class="fas fa-street-view"></i> <span class="hidden group-hover:inline text-sm">Roles</span> 
                </a>
              </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view users', 'create users', 'edit users','delete users'])): ?>
              <li class="flex">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="rounded mb-1 lg:w-full hover:bg-white hover:text-green-800 hover:rounded p-2 <?php echo e(request()->routeIs('admin.users*')?'bg-white text-green-800 ':''); ?>">
                  <i class="fas fa-users"> </i> <span class="hidden group-hover:inline text-sm"> Users</span> 
                </a>
              </li>
            <?php endif; ?>
          </ul>
        </div>
    </div>
    
  </div>
<?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/components/side-navigation-menu.blade.php ENDPATH**/ ?>