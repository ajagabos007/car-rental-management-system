<div >
    
    <form method="POST" action="https://checkout.flutterwave.com/v3/hosted/pay">    
        <input type="hidden" name="public_key" value="<?php echo e(env('FLUTTERWAVE_PUBLIC_KEY')); ?>" />
        <input type="hidden" name="customer[email]" value="<?php echo e($payment->paymentable->user->email); ?>" />
        <input type="hidden" name="customer[phone_number]" value="<?php echo e($payment->paymentable->user->phone_number); ?>" />
        <input type="hidden" name="customer[name]" value="<?php echo e($payment->paymentable->user->name); ?>" />
        <input type="hidden" name="tx_ref" value="<?php echo e($payment->transaction_reference); ?>" />
        <input type="hidden" name="amount" value="<?php echo e($payment->amount); ?>" />
        <input type="hidden" name="currency" value="NGN" />
        <input type="hidden" name="meta[token]" value="54" />
        <input type="hidden" name="redirect_url" value="<?php echo e(route('payments.verify', $payment)); ?>" />
        <button type="submit" class="btn-first btn-submit"> <?php echo e($text? $text: 'Pay Now'); ?></button>
    </form>
</div>
<?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/livewire/payment/flutterwave-checkout.blade.php ENDPATH**/ ?>