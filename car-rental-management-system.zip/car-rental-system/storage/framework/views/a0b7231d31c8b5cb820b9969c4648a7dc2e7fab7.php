<div>
    
     <?php $__env->slot('title', null, []); ?> 
        Payments
     <?php $__env->endSlot(); ?>   
     <?php $__env->slot('subheader', null, []); ?> 
        Payments
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('subheader_links', null, []); ?> 
        <li class="active fw-500">
            Payments
        </li>
     <?php $__env->endSlot(); ?>
    <section class="section-padding bg-light-white booking-form">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="tabs">
                        <ul class="custom-flex nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#payments">Payments (<?php echo e($payments->count()); ?>)</a>
                            </li>
                        </ul>
                        <div class="tab-content bg-custom-white bx-wrapper padding-20">

                            <div class="tab-pane fade active show" id="payments">
                                <div class="tab-inner">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="table-responsive">
                                            <table class="table table-hover table-striped table-dark">
                                                <caption class="fs-6 text-custom-blue">List of Payment</caption>
                                                <thead>
                                                    <tr>
                                                        <th scope="col" class="text-nowrap">#</th>
                                                        <th scope="col" class="text-nowrap">Transaction Reference</th>
                                                        <th scope="col" class="text-nowrap">Payment For</th>
                                                        <th scope="col" class="text-nowrap">Amount</th>
                                                        <th scope="col" class="text-nowrap">Paid on</th>
                                                        <th scope="col" class="text-nowrap">Verified on</th>
                                                        <th scope="col" class="text-nowrap">Status</th>
                                                        <th scope="col" class="text-nowrap">Actions</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                                            <td class="text-nowrap"><?php echo e($payment->transaction_reference); ?></td>
                                                            <td class="text-nowrap">
                                                                <a href="<?php echo e($payment->paymentable_url); ?>"><?php echo e($payment->for); ?></a>
                                                            </td>
                                                            <td class="text-nowrap active">
                                                                <a href="#"><?php echo e($payment->amount); ?></a>
                                                            </td>
                                                            <td class="text-nowrap"><?php echo e($payment->paid_on? $payment->paid_on :'NILL'); ?></td>
                                                            <td class="text-nowrap"><?php echo e($payment->verified_on ? $payment->verified_on: "NILL"); ?></td>
                                                            <td class="text-nowrap">
                                                                <?php if($payment and $payment->status != 'successful'): ?>
                                                                    <span class="bg-warning text-dark p-2">
                                                                        <?php echo e($payment->status); ?>

                                                                    </span> 
                                                                    <?php else: ?>
                                                                    <span class="bg-custom-blue p-2">
                                                                        <?php echo e($payment->status); ?>

                                                                    </span> 
                                                                <?php endif; ?>
                                                            </td>
                                                            <td class="text-nowrap">
                                                                <div class="action">
                                                                    <?php if($payment and $payment->status != 'successful'): ?>
                                                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment.flutterwave-checkout', ['payment' => $payment])->html();
} elseif ($_instance->childHasBeenRendered('l3721987675-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3721987675-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3721987675-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3721987675-0');
} else {
    $response = \Livewire\Livewire::mount('payment.flutterwave-checkout', ['payment' => $payment]);
    $html = $response->html();
    $_instance->logRenderedChild('l3721987675-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                                        <?php else: ?>
                                                                        <a href="<?php echo e(route('payments.show', $payment)); ?>" class="btn-second btn-submit bg-primary">View</a>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/livewire/payment/index.blade.php ENDPATH**/ ?>