<div>
    
     <?php $__env->slot('title', null, []); ?> 
        Cars
     <?php $__env->endSlot(); ?>   
     <?php $__env->slot('subheader', null, []); ?> 
        Cars
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('subheader_links', null, []); ?> 
        <li class="active fw-500">
            Cars
        </li>
     <?php $__env->endSlot(); ?>

<section class="section-padding bg-light-white">
<div class="container">
<div class="row">
<div class="col-lg-8">
<div class="row">
<div class="col-12">
<div class="listing-top-heading mb-xl-20">
<h6 class="no-margin text-custom-black">
    Showing <?php echo e($cars->count()); ?> / <?php echo e($cars->total()); ?> Results</h6>
    <!-- <div class="sort-by">
        <span class="text-custom-black fs-14 fw-600">Sort by</span>
        <div class="group-form">
            <select wire:model="sort" class="form-control form-control-custom custom-select">
                <option>A to Z</option>
                <option>Z to A</option>
            </select>
        </div>
    </div> -->
</div>
</div>
<?php $__empty_1 = true; $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6">
        <div class="hotel-grid mb-xl-30">
            <div class="hotel-grid-wrapper car-grid bx-wrapper">
                <div class="image-sec animate-img">
                    <a href="<?php echo e(route('cars.show', $car)); ?>" >
                        <img src="<?php echo e(Storage::url($car->image->url)); ?>" class="full-width" Style="height:210px;" alt="img">
                    </a>
                </div>
                <div class="hotel-grid-caption padding-20 bg-custom-white p-relative">
                    <h4 class="title fs-16"><a href="<?php echo e(route('cars.show', $car)); ?>" class="text-custom-black"><?php echo e($car->name); ?><small class="text-light-dark">1 Day</small></a></h4>
                    <span class="price"><small>From</small>NGN <?php echo e($car->price); ?></span>
                    <div class="action">
                        <a class="btn-second btn-small" href="<?php echo e(route('cars.show', $car)); ?>">View</a>
                        <a class="btn-first btn-submit" href="<?php echo e(route('cars.book', $car)); ?>">Rent</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-md-12">
        <h1 class="text-custom-black">Car rental, travel and tour Comming soon...!</h1>
        <h3 class="text-custom-blue">Contact the admin for more information</h3>
    </div>
<?php endif; ?>
</div>
    
</div>
<aside class="col-lg-4">
<div class="sidebar_wrap">
<div class="sidebar">
<div class="sidebar_widgets mb-xl-30">
<div class="widget_title bg-custom-blue">
<h5 class="no-margin text-custom-white">Modify Search</h5>
</div>
<form wire:submit.prevent="search">
    <div class="form-group">
        <label class="fs-14 text-custom-black fw-500">Search your favourite car</label>
        <input type="search" wire:model="data"  name="#" class="form-control form-control-custom" placeholder="seach by name or price">
    </div>
    <button class="btn-first btn-submit full-width btn-height">Search Now</button>
</form>
</div>
    <div class="sidebar_widgets mb-xl-30">
        <div class="widget_title bg-custom-blue">
            <h5 class="no-margin text-custom-white">Price NGN <?php echo e($min_price); ?> - <?php echo e($max_price); ?></h5>
            </div>
            <div class="widget_range">
                <div class="thc-range-inner flex ">
                    <input type="range" step="0.01" title="NGN <?php echo e($min_price); ?> " wire:model='min_price'  max="<?php echo e($slider_min_price); ?>" class="w-full h-3 bg-custom-blue appearance-none text-fuchsia-500 rounded-l cursor-pointer  dark:bg-gray-700">
                    <input type="range" step="0.01"  title="NGN <?php echo e($max_price); ?> " wire:model='max_price'  min="<?php echo e($slider_min_price); ?>"  max="<?php echo e($slider_max_price); ?>" class="w-full h-3 bg-custom-blue appearance-none  text-fuchsia-500 rounded-r cursor-pointer  dark:bg-gray-700">
                </div>
            </div>
        </div>
    </div>
</div>
</aside>
</div>
</div>
</section><?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/livewire/car/index.blade.php ENDPATH**/ ?>