<div>
    
    <a href="#" class="btn-first btn-submit" >
        <i class="fab fa-whatsapp"></i> Chat us now
    </a>
</div>
<?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/livewire/chat/whats-app-chat.blade.php ENDPATH**/ ?>