<div>
    
     <?php $__env->slot('title', null, []); ?> 
       Car/<?php echo e($car->name); ?>/Rent
     <?php $__env->endSlot(); ?>   
     <?php $__env->slot('subheader', null, []); ?> 
        Cars
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('subheader_links', null, []); ?> 
        <li class="fw-500">
            <a href="<?php echo e(route('cars.index')); ?>" class="text-custom-white">Cars</a>
        </li>

        <li class="fw-500">
        <a href="<?php echo e(route('cars.show',$car)); ?>" class="text-custom-white"><?php echo e($car->name); ?> </a>  
        </li>
        <li class="active fw-500">
            Book  
        </li>
     <?php $__env->endSlot(); ?>
    <section class="section-padding bg-light-white booking-form">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="tabs">
                        <ul class="custom-flex nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#cars-booking">Car <?php echo e($car->name); ?> renting</a>
                            </li>
                        </ul>
                        <div class="tab-content bg-custom-white bx-wrapper padding-20">

                            <div class="tab-pane fade active show" id="cars-booking">
                                <div class="tab-inner">
                                    <div class="row">
                                        <div class="col-lg-8">
                                            <h5 class="text-custom-black">Car Information</h5>
                                            <div class="row mb-md-80">
                                                <div class="col-lg-7">
                                                    <div class="image-sec animate-img mb-4">
                                                        <a href="#">
                                                            <?php if($car->image): ?>
                                                                <img src="<?php echo e(Storage::url($car->image->url)); ?>" class="full-width" style="height:240px;" alt="img">
                                                                <?php else: ?>
                                                                <img src="http://127.0.0.1:8000/kangyang/assets/images/cars/1.jpg" class="full-width" alt="img">
                                                            <?php endif; ?>
                                                        </a>
                                                    </div>
                                                    <hr>
                                                    <div class="title">
                                                        <h4 class="fs-16">
                                                            <i class="fas fa-car text-custom-blue"></i>
                                                            <a href="#" class="text-custom-black">  <?php echo e($car->name); ?> </a>
                                                            
                                                            <span class="price text-custom-blue mr-3">NGN <?php echo e($car->price); ?></span> 
                                                        </h4>   
                                                    </div>
                                                    <hr>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="hotel-type mb-xl-20 bg-light-white">
                                                        <ul class="" style="padding:20px; list-style:None;">
                                                            <li class="text-light-dark mb-2">
                                                                <label class="no-margin text-custom-blue">
                                                                Car Type:
                                                                </label><?php echo e($car->type? $car->type->name: __('Not stated')); ?>

                                                            </li>
                                                            <li class="text-light-dark mb-2">
                                                                <label class="no-margin text-custom-blue">
                                                                Rental Company:
                                                                </label><?php echo e($car->rental_company); ?>

                                                            </li>
                                                            <li class="text-light-dark mb-2">
                                                                <label class="no-margin text-custom-blue">
                                                               Max. Passengers:
                                                                </label><?php echo e($car->no_of_passenger); ?>

                                                            </li>
                                                            <li class="text-light-dark mb-2">
                                                                <label class="no-margin text-custom-blue">
                                                               Max. Baggage:
                                                                </label><?php echo e($car->no_of_baggage); ?>

                                                            </li>
                                                           
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <table class="table table-borderless border-0 table-collapse">
                                                        <tr>
                                                            <th>Price:</th>
                                                            <td>NGN <?php echo e($car->price); ?></td>
                                                        </tr>

                                                    </table>
                                                </div>
                                            </div>
                                            <h5 class="text-custom-black">Your Personal Information</h5>
                                            <form class="row mb-md-80" wire:submit.prevent="confirmBooking">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="fs-14 text-custom-black fw-500">Full Name</label>
                                                    
                                                        <?php if(auth()->guard()->check()): ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','id' => 'name','name' => 'name','class' => 'form-control form-control-custom '.e($errors->has('user.name') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.name','autocomplete' => 'user.name','placeholder' => 'Full Name','required' => true,'disabled' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','id' => 'name','name' => 'name','class' => 'form-control form-control-custom '.e($errors->has('user.name') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.name','autocomplete' => 'user.name','placeholder' => 'Full Name','required' => true,'disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'user.name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>  
                                                        <?php endif; ?>

                                                        <?php if(auth()->guard()->guest()): ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','id' => 'name','name' => 'name','class' => 'form-control form-control-custom '.e($errors->has('user.name') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.name','autocomplete' => 'user.name','placeholder' => 'Full Name','required' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','id' => 'name','name' => 'name','class' => 'form-control form-control-custom '.e($errors->has('user.name') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.name','autocomplete' => 'user.name','placeholder' => 'Full Name','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'user.name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>  
                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="fs-14 text-custom-black fw-500">Phone Number</label>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'tel','id' => 'name','name' => 'name','class' => 'form-control form-control-custom '.e($errors->has('user.phone_number') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.phone_number','autocomplete' => 'user.phone_number','placeholder' => 'Phone Number','required' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'tel','id' => 'name','name' => 'name','class' => 'form-control form-control-custom '.e($errors->has('user.phone_number') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.phone_number','autocomplete' => 'user.phone_number','placeholder' => 'Phone Number','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'user.phone_number']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.phone_number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="fs-14 text-custom-black fw-500">Email</label>
                                                        <?php if(auth()->guard()->check()): ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','id' => 'email','name' => 'email','class' => 'form-control form-control-custom '.e($errors->has('user.email') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.email','autocomplete' => 'user.email','placeholder' => 'Full Name','required' => true,'disabled' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','id' => 'email','name' => 'email','class' => 'form-control form-control-custom '.e($errors->has('user.email') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.email','autocomplete' => 'user.email','placeholder' => 'Full Name','required' => true,'disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'user.email']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                                        <?php endif; ?>

                                                        <?php if(auth()->guard()->guest()): ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','id' => 'email','name' => 'email','class' => 'form-control form-control-custom '.e($errors->has('user.email') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.email','autocomplete' => 'user.email','placeholder' => 'Full Name','required' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','id' => 'email','name' => 'email','class' => 'form-control form-control-custom '.e($errors->has('user.email') ? 'is-invalid' : '').'','wire:model.lazy' => 'user.email','autocomplete' => 'user.email','placeholder' => 'Full Name','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'user.email']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <label class="custom-checkbox mb-0">
                                                        <input type="checkbox" name="#">
                                                        <span class="checkmark"></span>
                                                        I want to receive <a href="#">Company name</a> promotional offers in the future
                                                    </label>
                                                </div>
                                                <div class="col-12">
                                                    <hr>
                                                </div>

                                                <!-- Hide Your Card Information -->
                                                <?php if(0): ?>
                                                    <div class="col-12">
                                                        <h5 class="text-custom-black">Your Card Information</h5>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="fs-14 text-custom-black fw-500">Card Type</label>
                                                            <div class="group-form">
                                                                <select class="custom-select form-control form-control-custom">
                                                                    <option>Select Card</option>
                                                                    <option>Visa</option>
                                                                    <option>Master Card</option>
                                                                    <option>Credit Card</option>
                                                                    <option>Americal Express</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="fs-14 text-custom-black fw-500">Card Holder Name</label>
                                                            <input type="text" name="#" class="form-control form-control-custom" placeholder="Card Holder Name" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="fs-14 text-custom-black fw-500">Card Number</label>
                                                            <input type="text" name="#" class="form-control form-control-custom" placeholder="Card Number" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="fs-14 text-custom-black fw-500">Card Identification Number</label>
                                                            <input type="text" name="#" class="form-control form-control-custom" placeholder="Card Identification Number" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="row">
                                                            <div class="col-sm-6">
                                                                <div class="form-group">
                                                                    <label class="fs-14 text-custom-black fw-500">Expiration Month</label>
                                                                    <div class="group-form">
                                                                        <select class="custom-select form-control form-control-custom">
                                                                            <option>Month</option>
                                                                            <option>Jan</option>
                                                                            <option>Feb</option>
                                                                            <option>Mar</option>
                                                                            <option>Apr</option>
                                                                            <option>May</option>
                                                                            <option>June</option>
                                                                            <option>July</option>
                                                                            <option>Aug</option>
                                                                            <option>Sep</option>
                                                                            <option>Oct</option>
                                                                            <option>Nov</option>
                                                                            <option>Dec</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <div class="form-group">
                                                                    <label class="fs-14 text-custom-black fw-500">Expiration Year</label>
                                                                    <div class="group-form">
                                                                        <select class="custom-select form-control form-control-custom">
                                                                            <option>2020</option>
                                                                            <option>2021</option>
                                                                            <option>2022</option>
                                                                            <option>2023</option>
                                                                            <option>2024</option>
                                                                            <option>2025</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="fs-14 text-custom-black fw-500">Billing Zip Code</label>
                                                            <input type="text" name="#" class="form-control form-control-custom" placeholder="Billing Zip Code" required>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                                <!-- End of Hide Your card Information  -->
                                                <div class="col-12">
                                                    <!-- <hr class="mt-0"> -->
                                                    <!-- <div class="form-group">
                                                        <label class="custom-checkbox">
                                                            <input type="checkbox" name="#">
                                                            <span class="checkmark"></span>
                                                            By continuing, you agree to the<a href="#">Terms and Conditions.</a>
                                                        </label>
                                                    </div> -->
                                                    <button type="submit" class="btn-first btn-submit">
                                                        <div wire:loading wire:target="confirmBooking" class="spinner-border spinner-border-sm" role="status"></div>
                                                        Confirm Rental
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="row">
                                                <div class="col-12">
                                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('need-help', [])->html();
} elseif ($_instance->childHasBeenRendered('l4034095632-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4034095632-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4034095632-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4034095632-0');
} else {
    $response = \Livewire\Livewire::mount('need-help', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4034095632-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/livewire/car/book.blade.php ENDPATH**/ ?>