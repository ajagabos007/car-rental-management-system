<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumb_links', null, []); ?> 
        <li> 
            <span>/</span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.nav-link','data' => ['href' => '#','active' => request()->routeIs('admin.cars.index')]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '#','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.cars.index'))]); ?>
                <?php echo e(__('Cars')); ?> 
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </li>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header', null, []); ?> 
       <i class="fas fa-car"></i> Cars 
     <?php $__env->endSlot(); ?>
    <div class="container px-2 mx-auto  dark:text-gray-100">
        <h2 class="mb-2 text-2xl font-semibold leading-tight flex gap-4 ">
            <span class="font-semibold">List of cars</span>
            <a href="<?php echo e(route('admin.cars.create')); ?>">
                <i class="fas fa-plus-circle text-md text-slate-700 hover:scale-105"></i>
            </a>
        </h2>
        <?php echo e($cars->links()); ?>


        <div class="overflow-auto rounded shadow-sm">
            <table class="w-full" >
                <thead class="table-header-group dark:bg-gray-700">
                    <tr class="border-b-4 bg-black text-white font-extrabold">
                        <th class="text-left py-1 px-4 whitespace-nowrap">#</th>
                        <th class="text-left py-1 px-4 whitespace-nowrap">Name</th>
                        <th class="text-left py-1 px-4 whitespace-nowrap ">Type</th>
                        <th class="text-left py-1 px-4 whitespace-nowrap">Passenger</th>
                        <th class="text-left py-1 px-4 whitespace-nowrap">Baggage</th>
                        <th class="text-left py-1 px-4 whitespace-nowrap">Price (NGN)</th>
                        <th class="text-left py-1 px-4 whitespace-nowrap">Created</th>
                        <th class="text-left py-1 px-4 whitespace-nowrap">Updated</th>
                        <th class="text-center py-1 px-4 whitespace-nowrap">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b-2 text-sm hover:bg-green-100 odd:bg-white even:text-green-900'">
                        <td class="py-1 px-4 whitespace-nowrap">
                            <?php echo e(++$loop->index); ?>

                        </td>
                        <td class="py-1 px-4 whitespace-nowrap">
                            <a href="<?php echo e(route('admin.cars.show', $car)); ?>" class="flex -space-x-2 mr-2 text-blue-700 hover:underline ">
                                <?php if($car->image): ?>
                                    <img src="<?php echo e(Storage::url($car->image->url)); ?>" class="rounded-full w-6 h-6 border border-white mr-2" alt="img">
                                <?php endif; ?>
                                <?php echo e($car->name); ?>

                            </a>  
                        </td>
                        <td class="py-1 px-4 whitespace-nowrap">
                            <?php echo e($car->type->name); ?>

                        </td>
                        <td class="py-1 px-4 whitespace-nowrap">
                            <?php echo e($car->no_of_passenger); ?>

                        </td>
                        <td class="py-1 px-4 whitespace-nowrap">
                            <?php echo e($car->no_of_baggage); ?>

                        </td>

                        <td class="py-1 px-4 whitespace-nowrap">
                            <?php echo e($car->price); ?>

                        </td>
                        <td class="py-1 px-4 whitespace-nowrap">
                            <?php echo e($car->created_at->diffForHumans()); ?>

                        </td>
                        <td class="py-1 px-4 whitespace-nowrap">
                            <?php echo e($car->updated_at->diffForHumans()); ?>

                        </td>
                        <td class="py-1 px-4 whitespace-nowrap text-center">
                            <div class="inline-flex rounded-md shadow-sm" role="group">
                               <a href="<?php echo e(route('admin.cars.show', $car)); ?>" class="inline-flex items-center py-1 px-4 text-sm font-medium text-gray-900 bg-transparent rounded-l-md border border-gray-900 hover:bg-gray-900 hover:text-white focus:z-10 focus:ring-2 focus:ring-gray-500 focus:bg-gray-900 focus:text-white dark:border-white dark:text-white dark:hover:text-white dark:hover:bg-gray-700 dark:focus:bg-gray-700">
                                    <i class="fas fa-eye pr-1"></i>
                                    View
                                </a>
                                
                                
                                <a href="<?php echo e(route('admin.cars.edit', $car)); ?>" class="inline-flex items-center py-1 px-4 text-sm font-medium text-blue-900 bg-transparent  border border-blue-900 hover:bg-blue-900 hover:text-white focus:z-10 focus:ring-2 focus:ring-gray-500 focus:bg-blue-900 focus:text-white dark:border-white dark:text-white dark:hover:text-white dark:hover:bg-blue-700 dark:focus:bg-blue-700">
                                    Edit 
                                    <i class="fas fa-pen pl-1"></i>
                                </a>
                                <form action="<?php echo e(route('admin.cars.destroy', $car)); ?>" method="post" class="inline-flex items-center py-1 px-4 text-sm font-medium text-red-900 bg-transparent rounded-r-lg border border-red-900 hover:bg-red-900 hover:text-white focus:z-10 focus:ring-2 focus:ring-gray-500 focus:bg-red-900 focus:text-white dark:border-white dark:text-white dark:hover:text-white dark:hover:bg-red-700 dark:focus:bg-red-700">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit">
                                        Delete <i class="fas fa-trash pl-1"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/admin/cars/index.blade.php ENDPATH**/ ?>