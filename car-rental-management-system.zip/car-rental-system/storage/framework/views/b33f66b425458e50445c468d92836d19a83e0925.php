<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        About Us
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('subheader', null, []); ?> 
        About Us
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('subheader_links', null, []); ?> 
        <li class="active fw-500">
            About Us
        </li>
     <?php $__env->endSlot(); ?>
     
<section class="section-padding partners">
    <div class="container">
        <div class="section-header">
            <div class="section-heading">
                <h3 class="text-custom-black">About Us</h3>
                <div class="section-description">
                    <p class="text-light-dark"><?php echo e(env('APP_NAME')); ?></p>
                </div>
            </div>
        </div>
        <div class="section-content">
            <p> <strong class="h4 text-capitalize text-custom-blue" ><?php echo e(env('APP_NAME')); ?> </strong> is a Nigerian based company that provides a variety of car rental services. Our main priority is to give you the most comfortable and affordable car mobility to any part of the globe.</p>

            <p>We provide classics cars with suitable amenities for rents at affordable price</p>

            <p>Other services we offer include car repairs, engine oiling, car tours to placies of your fantasy.<p>

            <p>You can be rest assured that you will be treated with the warmest reception by our hospitable and carefully selected staff.</p>

            <p>We have made our payment modes convenient for clients and that is why <span class="text-bold text-custom-blue" ><?php echo e(env('APP_NAME')); ?></span> also accepts payment In crypto currencies. Payment links and invoices will be generated and shared as requested by clients.</p>
        </div>
    </div>
</section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/about-us.blade.php ENDPATH**/ ?>