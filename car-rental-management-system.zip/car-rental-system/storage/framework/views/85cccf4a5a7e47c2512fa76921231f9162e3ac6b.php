<div>
    
     <?php $__env->slot('title', null, []); ?> 
        Gallery
     <?php $__env->endSlot(); ?>   
     <?php $__env->slot('subheader', null, []); ?> 
        Gallery
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('subheader_links', null, []); ?> 
        <li class="active fw-500">
            Gallery
        </li>
     <?php $__env->endSlot(); ?>
    <section class="section-padding bg-light-white gallery">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="tabs filter-gallery">
                        <ul class="custom-flex nav nav-tabs mb-xl-40">
                            <li class="nav-item">
                                <a class="nav-link active" href="#" data-filter="*">All</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-filter=".car-gallery">Cars</a>
                            </li>
                        </ul>
                    </div>
                    <div class="row gallery-grid">
                    <?php $__currentLoopData = App\Models\Image::all()->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $gallery_class = '';
                                if($image->imageable_type == App\Models\Car::class)
                                $gallery_class = 'car-gallery';
                            ?>
                            <div class="col-lg-4 col-md-6 filter-box <?php echo e($gallery_class); ?>">
                                <div class="gallery-item mb-xl-30">
                                    <a href="<?php echo e(Storage::url($image->url)); ?>" class="popup">
                                        <img src="<?php echo e(Storage::url($image->url)); ?>" class="image-fit" style="height:250px;" alt="img">
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/livewire/gallery/index.blade.php ENDPATH**/ ?>