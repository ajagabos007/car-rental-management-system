<div>
    
     <?php $__env->slot('title', null, []); ?> 
       Renting <?php echo e($booking->code); ?>

     <?php $__env->endSlot(); ?>   
     <?php $__env->slot('subheader', null, []); ?> 
        Rentings
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('subheader_links', null, []); ?> 
        <li class="fw-500">
            <a href="<?php echo e(route('bookings.index')); ?>" class="text-custom-white">Rentings</a>
        </li>

        <li class="active fw-500">
            <?php echo e($booking->code); ?>  
        </li>
     <?php $__env->endSlot(); ?>
    <section class="section-padding bg-light-white booking-form">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="tabs">
                        <ul class="custom-flex nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#flights-booking">Renting <code class="border-bottom border-white"><?php echo e($booking->code); ?></code></a>
                            </li>
                            <?php if(!$booking->payment->exists() or $booking->payment->status != 'successful'): ?>
                                <li class="nav-item my-2">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chat.whats-app-chat', [])->html();
} elseif ($_instance->childHasBeenRendered('l404968071-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l404968071-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l404968071-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l404968071-0');
} else {
    $response = \Livewire\Livewire::mount('chat.whats-app-chat', []);
    $html = $response->html();
    $_instance->logRenderedChild('l404968071-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </li>
                                <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('payments.show', $booking->payment)); ?>">
                                        Paid
                                        <i class="fas fa-check"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                        <div class="tab-content bg-custom-white bx-wrapper padding-20">
                            <div class="tab-pane fade active show" id="flights-booking">
                                <div class="tab-inner">
                                    <div class="row">
                                        <div class="col-lg-8">
                                            <h5 class="text-custom-black">Beneficial Information</h5>
                                            <div class="form">
                                                <div class="row mb-md-10">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label class="fs-14 text-custom-black fw-500">Full Name</label>
                                                            <input disabled="" class="form-control form-control form-control-custom" type="text" id="name" name="name" wire:model.lazy="user.name" autocomplete="user.name" placeholder="Full Name" required="required">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="fs-14 text-custom-black fw-500">Phone Number</label>
                                                            <input class="form-control form-control form-control-custom" type="tel" id="name" name="name" wire:model.lazy="user.phone_number" autocomplete="user.phone_number" placeholder="Phone Number" required="required">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="fs-14 text-custom-black fw-500">Email</label>
                                                            <input disabled="" class="form-control form-control form-control-custom" type="text" id="email" name="email" wire:model.lazy="user.email" autocomplete="user.email" placeholder="Full Name" required="required">
                                                        </div>
                                                    </div>
                                                
                                                    <div class="col-12">
                                                        <hr>
                                                    </div>

                                                    <!-- Hide Your Card Information -->
                                                    <!-- End of Hide Your card Information  -->
                                                    <div class="col-12">
                                                        <hr class="mt-0">
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">
                                                                <input type="checkbox" name="#">
                                                                <span class="checkmark"></span>
                                                                By continuing, you agree to the<a href="#">Terms and Conditions.</a>
                                                            </label>
                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                                <h5 class="text-custom-black">Rent Information</h5>
                                                <div class="row mb-md-10">
                                                    <div class="col-lg-12">
                                                        <div class="hotel-type mb-xl-20 bg-light-white">
                                                            <table class="table table-borderless border-0 table-collapse">
                                                                <tbody>
                                                                    <tr>
                                                                        <th>Rent Code:</th>
                                                                        <td class="text-custom-blue" > <a href="<?php echo e(route('bookings.show', $booking)); ?>"><?php echo e($booking->code); ?></a></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Rent Item:</th>
                                                                        <td class="text-custom-blue">

                                                                            <a href="<?php echo e($booking->bookable_url); ?>">
                                                                                <?php if($booking->bookable_type == App\Models\Flight::class): ?>
                                                                                    <?php echo e($booking->bookable->number); ?>

                                                                                <?php else: ?>
                                                                                    <?php echo e($booking->bookable->name); ?>

                                                                                <?php endif; ?>
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Booked:</th>
                                                                        <td class="text-custom-blue"><?php echo e($booking->created_at->diffForHumans()); ?></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>

                                                <h5 class="text-custom-black">Amount Information</h5>
                                                <div class="row mb-md-10 ">
                                                    <div class="col-lg-12 ">
                                                        <table class="table table-borderless border-0 table-collapse mb-xl-20 bg-light-white">
                                                            <tbody>
                                                                <tr class="border text-custom-blue">

                                                                    <th>Amount:</th>
                                                                    <td>₦ <?php echo e($booking->amount); ?></td>
                                                                </tr>

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <?php if(!$booking->payment->exists() or $booking->payment->status != 'successful'): ?>
                                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment.flutterwave-checkout', ['payment' => $booking->payment])->html();
} elseif ($_instance->childHasBeenRendered('l404968071-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l404968071-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l404968071-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l404968071-1');
} else {
    $response = \Livewire\Livewire::mount('payment.flutterwave-checkout', ['payment' => $booking->payment]);
    $html = $response->html();
    $_instance->logRenderedChild('l404968071-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="row">
                                                <div class="col-12">
                                                  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('need-help', [])->html();
} elseif ($_instance->childHasBeenRendered('l404968071-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l404968071-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l404968071-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l404968071-2');
} else {
    $response = \Livewire\Livewire::mount('need-help', []);
    $html = $response->html();
    $_instance->logRenderedChild('l404968071-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /opt/lampp/htdocs/car-rental-system/resources/views/livewire/booking/show.blade.php ENDPATH**/ ?>