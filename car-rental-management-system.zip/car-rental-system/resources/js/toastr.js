import * as toastr from '../../node_modules/toastr/build/toastr.min.js';
window.toastr = toastr;
