<x-app-layout>

    <x-slot name="title">
        Dashboard
    </x-slot>
    <x-slot name="subheader">
        Dashboard
    </x-slot>
    <x-slot name="subheader_links">
        <li class="active fw-500">
            Dashboard
        </li>
    </x-slot>

    <x-jet-welcome />
</x-app-layout>