<div>
    {{-- Because she competes with no one, no one can compete with her. --}}
    <a href="#" class="btn-first btn-submit" >
        <i class="fab fa-whatsapp"></i> Chat us now
    </a>
</div>
