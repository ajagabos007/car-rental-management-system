<div>
    {{-- If your happiness depends on money, you will never be happy with yourself. --}}
    <x-slot name="title">
       Blogs
    </x-slot>   
    <x-slot name="subheader">
        Blogs
    </x-slot>
    <x-slot name="subheader_links">
        <li class="active fw-500">
           Blogs  
        </li>
    </x-slot>
</div>
