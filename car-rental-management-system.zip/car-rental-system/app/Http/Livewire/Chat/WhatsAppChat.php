<?php

namespace App\Http\Livewire\Chat;

use Livewire\Component;

class WhatsAppChat extends Component
{
    public function render()
    {
        return view('livewire.chat.whats-app-chat');
    }
}
