<?php

namespace App\Http\Livewire\Service;

use Livewire\Component;

class Show extends Component
{
    public function render()
    {
        return view('livewire.service.show');
    }
}
