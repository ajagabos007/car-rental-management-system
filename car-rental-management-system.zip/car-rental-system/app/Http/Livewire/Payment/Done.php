<?php

namespace App\Http\Livewire\Payment;

use Livewire\Component;

class Done extends Component
{
    public function render()
    {
        return view('livewire.payment.done');
    }
}
